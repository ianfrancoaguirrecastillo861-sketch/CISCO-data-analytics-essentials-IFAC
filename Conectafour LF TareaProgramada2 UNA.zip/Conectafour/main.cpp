/*/
	<UNIVERSIDAD NACIONAL DE COSTA RICA>

	Fundamentos de informatica || EIF200. NRC 41268. I ciclo de 2026
	Profesora: Marianela Solano Orias.
	Estudiantes: Lester Goicochea, Ian Franco Aguirre. (Grupo 7)

	Tarea programada 2 || (Proyecto_4enRaya_C++)
	Este proyecto consiste en la implementacion del clasico juego 4 en raya utilizando el lenguaje de programacion C++. Los estudiantes 
	deberan aplicar conocimientos de arreglos, vectores, funciones, estructuras de control y logica de programacion para construir  una
	aplicacion funcional, interactiva y con interfaz de consola.

/*/

#include<iostream>
#include<ctime>
#include<climits>
#include<windows.h>

using namespace std;

const int m = 6; // filas
const int n = 7; // columnas

bool verificarGanador(char tablero[m][n]){ //funcion que verifica lineas de 4 horizontales, verticales y diagonales.
	
	for(int i=0;i<m;i++){ //Lee y verifica las lineas horizontales
		for(int j=0;j<n-3;j++){
			if(tablero[i][j]!= '-' 
				&& tablero[i][j]==tablero[i][j+1]
				&& tablero[i][j]==tablero[i][j+2] 
				&& tablero[i][j]==tablero[i][j+3]){
				return true;
			}
		}
	}
	for(int i=0;i<m-3;i++){ //Lee y verifica las lineas verticales
		for(int j=0;j<n;j++){
			if(tablero[i][j] != '-'
				&& tablero[i][j]==tablero[i+1][j] 
				&& tablero[i][j]==tablero[i+2][j] 
				&& tablero[i][j]==tablero[i+3][j]){
				return true;
			}
		}
	}
	for(int i=0;i<m-3;i++){ //Lee y verifica la diagonal principal
		for(int j=0;j<n-3;j++){
			if(tablero[i][j] != '-' 
				&& tablero[i][j]==tablero[i+1][j+1] 
				&& tablero[i][j]==tablero[i+2][j+2] 
				&& tablero[i][j]==tablero[i+3][j+3]){
				return true;
			}
		}
	}
	for(int i=0;i<m-3;i++){ //Lee y verifica la diagonal secundaria
		for(int j=3;j<n;j++){
			if(tablero[i][j] != '-' 
				&& tablero[i][j]==tablero[i+1][j-1] 
				&& tablero[i][j]==tablero[i+2][j-2] 
				&& tablero[i][j]==tablero[i+3][j-3]){
				return true;
			}
		}
	}
	return false;
}
void colour(int c){ //funcion pra poner colores a los textos del programa, 'colour' para no confundir con color ni con 'colorFicha'
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c); //poner colores para texto en Zinjai con windows :)
}

void modoDeJuego(int &modoJuego){ //Menu principal
	colour(7);
	cout<<"+-------------------------------+"<<endl;
	colour(9);
	cout<<"|    J U E G O 4 E N R A Y A    | "<<endl; 		//titulo del juego
	colour(7);
	cout<<"+-------------------------------+"<<endl;
	colour(7);
	cout<<"Ingrese el modo que desea jugar:"<<endl<<endl; 
	colour(6);
	cout<<" 1."; 											//opcion 1 a jugar
	colour(7);
	cout<<" Jugador vs Jugador"<<endl;
	colour(6);
	cout<<" 2.";											//opcion 2 a jugar
	colour(7);
	cout<<" Jugador vs Maquina"<<endl;
	colour(12);
	cout<<" 3.";											//salir del juego
	colour(7);
	cout<<" Salir del juego"<<endl;
	colour(10);
	cout<<endl<<" Ingresa tu opcion... ";
	colour(9);
	cin>>modoJuego;
	cout<<endl;
	
	switch(modoJuego){ //muestra la opcion elegida como modo de juego
	case 1:
		colour(3);
		cout<<" |MODO| Jugador VS Jugador >"<<endl; //2 jugadores
		break;
		
	case 2:
		colour(3);
		cout<<" |MODO| < Jugador VS Maquina >"<<endl; //vs maquina
		break;
		
	case 3:
		colour(7);
		cout<<" !!Gracias por jugar!!"<<endl; //salida...
		exit(0);
		
	default: //valida otro numero, letra o caracter
		colour(4);
		cout<<endl<<"   Modo de juego invalido!"<<endl<<endl;
		modoDeJuego(modoJuego);
		break;
	}
}
	
void colorFicha(char &jugador,char colores[],int color){ //funcion que asigna el color a las fichas
	while (true){
		int error=0;
		colour(9);
		cout<<endl<<"---Configuracion de jugadores---"<<endl<<endl; //titulo 
		colour(7);
		cout<<"Ingrese el color que desea utilizar el jugador "; //mensaje para elegir el color
		if (cin.fail()) { // detecta si el usuario meti� una letra
			cin.clear();   // limpia el estado de error de cin
			cin.ignore(10000, '\n'); //descarta la letra del buffer
			cout << " �Debe ingresar un numero entero!" << endl << endl;
			error = 1;
		}
		if(jugador=='Z'){
			cout<<"1"<<endl; //jugador 1
		}
		else{
			cout<<"2"<<endl; //jugador 2
		}
		
		for(int i=0;i<4;i++){
			if(colores[i]!='X'){
				switch(colores[i]){ //colores elegibles
				case 'R':
					colour(4);
					cout<<"1.";
					colour(7);
					cout<<"Rojo	"; //opcion 1. rojo
					break;
				case 'A':
					colour(1);
					cout<<"2-";
					colour(7);
					cout<<"Azul	"; //opcion 2. azul
					break;
				case 'V':
					colour(2);
					cout<<"3-";
					colour(7);
					cout<<"Verde "; //opcion 3. verde
					break;
				case 'M':
					colour(6);
					cout<<"4-";
					colour(7);
					cout<<"Amarillo	"; //opcion 4. amarillo
					break;
				}
			}
		}
		cin>>color;
		
		if(color < 1 || color > 4){ //valida los rangos de los colores
			cout<<" Color invalido!"<<endl<<endl;
			error=1;
		}
		
		if(colores[color-1]=='X'){ //valida si ya se eligio esa opcion
			cout<<endl<<" Este color ya fue elegido, por favor vuelva a elegir"<<endl<<endl;
			error=1;
		}
	if (error==0){
		switch(color){ //asigna el color elegido al jugador y marca ese color como ocupado para que el siguiente jugador no pueda seleccionarlo
		case 1:
			jugador=colores[0];
			colores[0]='X';
			break;
			
		case 2:
			jugador=colores[1];
			colores[1]='X';
			break;
			
		case 3:
			jugador=colores[2];
			colores[2]='X';
			break;
			
		case 4:
			jugador=colores[3];
			colores[3]='X';
			break;
		}
		break;
		}
	}
}

void imprimirTablero(char tablero[m][n]){ //funcion que genera el tablero, las lineas y las fichs sus colores designados
	colour(15); //color de las columnas: blanco brillante
	for(int j=1;j<=n;j++){
		cout<<"   "<<j;
	}
	cout<<endl<<" +---+---+---+---+---+---+---+"<<endl; //imprime los bordes superiores
		for(int i=0;i<m;i++){
		cout<<" | ";
			for(int j=0;j<n;j++){
			char ficha = tablero[i][j]; 	//Asignamos los colores a las fichas
				
			if(ficha == 'R')colour(4); 		//rojo claro
			else if(ficha == 'A')colour(1); //azul
			else if(ficha == 'V')colour(2); //verde claro
			else if(ficha == 'M')colour(6); //amarillo claro
			else colour(7);  				//casillas vacias
				
			cout << ficha;
			
			colour(15); // Restaurar a blanco para las l�neas del tablero '|'
			cout<<" | ";
			}
		cout<<endl;
		cout<<" +---+---+---+---+---+---+---+"<<endl; //imprime los bordes inferiores
		
	}
	colour(9);//color de turno 1
		
}
void ponerFicha(char tablero[m][n], char jugador) { //funcion que coloca la ficha, valida la columna, valida si esta llena y reinicia
		int columna = 0;
		while (true) {//bucle pa
			bool colocada = false; //se reinicia a false en cada intento del bucle
			
			colour(7);
			cout << " �En que posicion desea colocar la ficha? (1-7)" << endl;
			cin >> columna; //recibe el numero del 1 al 7
			
			if (columna < 1 || columna > 7){ //valida los parametros del 1 al 7
				colour(4);
				cout << " Esa columna no existe!" << endl; //si es menor o mayor a esa cantidad avisa:
				cout << " Ingrese una nueva posicion!" << endl;
			}
			else { //simula la gravedad del juego y hace que la ficha caiga hasta el fondo de la columna elegida
				for (int i = m - 1; i >= 0; i--){  //el bucle arranca en la �ltima fila (m - 1) y sube hacia la primera (i--)
					if (tablero[i][columna - 1] == '-'){ //el if detecta la primera casilla vac�a ('-') disponible
						tablero[i][columna - 1] = jugador;
						colocada = true; //guarda la ficha del jugador
						break; //break para detenerse
					}
				}
				
				if (!colocada){//verifica si se lleno la columna
					colour(4);
					cout <<" La columna esta llena" <<endl; //avisa que SI se lleno
					cout <<" Ingrese otra columna!" <<endl; //pide ingresar en otra posicion
				}
				else {
					break; //sale del bucle 
				}
			}
		}
	}
	
void IAbasica(char tablero[m][n], char ia, char jugador){//Inteligencia Artificial basica que ataca, bloquea y juega estrategicamente
	
	for (int j = 0; j<n; j++){ // PRIORIDAD 1. intentar ganar 
			for (int i = m - 1; i >= 0; i--){//busca la primera casilla vac�a ('-') desde abajo hacia arriba en cada columna
					if (tablero[i][j] == '-'){ 
							tablero[i][j] = ia; //coloca temporalmente su ficha (tablero[i][j] = ia;) 
							if (verificarGanador(tablero)){//si gana deja la ficha ah� y sale de la funci�n con return (termina su turno)
									return; 
							}
							tablero[i][j] = '-'; //si no gana retira la ficha y rompe el ciclo interno para evaluar la siguiente columna
							break; 
					}
			}
	}
		
	for (int j = 0; j < n; j++) {// PRIORIDAD 2. bloquear al rival
			for (int i = m - 1; i >= 0; i--) {
					if (tablero[i][j] == '-'){//busca la casilla vac�a de la columna
							tablero[i][j] =jugador;  //coloca temporalmente la ficha del rival (tablero[i][j] = jugador;). 
							if (verificarGanador(tablero)) { //eval�a si esa jugada le dar�a la victoria al jugador 1
									tablero[i][j] = ia; //si eso pasa, cambia esa pieza por la suya propia para bloquear el "4 en raya" del jugador 1
									return;			// termina su turno
							}
							tablero[i][j] = '-'; //si el jugador no gana, retira la ficha de prueba y contin�a buscando en las dem�s columnas
							break;
					}
			}
	}

	int ordenEstrategico[] = {3, 2, 4, 1, 5, 0, 6}; //PRIORIDAD 3. si no hay jugadas para ganar ni para bloquear se usa ordenEstrategico
	for(int k = 0; k < n; k++) { // jugar en posici�n estrat�gica, controlar las columnas del centro otorga el mayor control del tablero
	int j = ordenEstrategico[k];  //la IA primero la columna central 3, luego las adyacentes 2 y 4, despu�s 1 y 5, y finalmente los extremos 0 y 6
		for (int i = m - 1; i >= 0; i--) {
			if (tablero[i][j] == '-') {
				tablero[i][j] = ia; //en la primera de estas columnas que encuentre con espacio libre, colocar� su ficha de forma permanente
			return; 				//finalizar� su turno.
			}
		}
	}
}
void Juego(){ //funcion que desarrolla el juego con todas las demas funciones.
	int cuentaTurnos=0; //comienza a contar cuantas fichas se han jugado
	char tablero[m][n]={ //genera el tablero
	{'-','-','-','-','-','-','-'},
	{'-','-','-','-','-','-','-'},
	{'-','-','-','-','-','-','-'},
	{'-','-','-','-','-','-','-'},
	{'-','-','-','-','-','-','-'},
	{'-','-','-','-','-','-','-'}};
	
	char jugador1='Z', jugador2;
	char colores[4]={'R','A','V','M'}; //fichas
	int color=0;
	int modoJuego=0;

	int fichasJ1 = 21; //contador de fichas del jugador1
	int fichasJ2 = 21; //fichas jugador 2 o maquina
	
	modoDeJuego(modoJuego);
	colorFicha(jugador1,colores,color);
	colorFicha(jugador2,colores,color);
	
	while(true){ //turno 1
		
		system("cls"); // borra el tablero viejo y lo actualiza
		
		if (cuentaTurnos >= 42||fichasJ1 == 0){ 
			colour(6);
			cout<< " El juego ha terminado en empate!" << endl;
			break;
		}
		
		imprimirTablero(tablero);
		cout <<endl <<" Turno del JUGADOR #1. Fichas restantes ["<<fichasJ1<< "]" << endl;
		ponerFicha(tablero, jugador1);
		cuentaTurnos++;
		fichasJ1--; //restar ficha al jugador 1
		
		if(verificarGanador(tablero)){ //verificar si gano el jugador 1
			system("cls");
			imprimirTablero(tablero);
			colour(6);
			cout << "Gano el jugador #1" << endl;
			break;
		}
		system("cls"); //turno del jugador2 o la maquina
		
		if (cuentaTurnos >= 42 || fichasJ2 == 0){//validar si el juego termina antes de que tire el J2
			colour(6);
			cout << " El juego ha terminado en empate" << endl;
			break;
		}
		
		imprimirTablero(tablero); 
		
		if(modoJuego == 1){
			colour(13);
			cout << endl << " Turno del JUGADOR #2. Fichas restantes [" << fichasJ2 << "]" <<endl;
			ponerFicha(tablero, jugador2);
			cuentaTurnos++;
			fichasJ2--;//restar ficha al jugador 2
		}
		else if(modoJuego == 2){
			cout << endl;
			colour(11);
			cout << " Turno de la Maquina. Fichas restantes [ " << fichasJ2 << " ]" <<endl;
			IAbasica(tablero, jugador2, jugador1); 
			cuentaTurnos++;
			fichasJ2--; //restar ficha a la m�quina
		}
		
		if(verificarGanador(tablero)){//verificar si gan� el Jugador 2 o la M�quina
			system("cls");
			imprimirTablero(tablero);
			if(modoJuego == 1){
				colour(6);
				cout << " Gano el jugador #2" << endl;
			}
			else{
				colour(6);
				cout << " Gano la Maquina!" << endl;
			}
			break;
		}
	} //fin del while
}//fin de la funcion juego
	
int main(){ //main del proyecto
	char opcion;
	do{ //al terminar la partida, limpia la pantalla y le pregunta al usuario si desea continuar.		
		system("cls"); 
	Juego(); //llama a la funcion y se desarrolla el juego 
	colour(15);
	cout<<endl<< " �Desea volver a jugar?"; //pregunta al usuario
	colour(1);
	cout<<" S "; //si
	colour(15);
	cout<<"/";
	colour(4);
	cout<<" N "<<endl;//no
	colour(10);
	cin>>opcion;
	
}
while(opcion == 'S' || opcion == 's'); //validar S y s
	colour(11);
	cout<<endl<< "� Gracias por jugar nuestro 4 en raya !"<<endl;
	colour(7);

	return 0;
}	
